export const SETTINGS_KEY = 'haunted-portrait-session-v1';
export function getSettings(){ try{return {room:'halloween',pin:'',...JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')}}catch{return {room:'halloween',pin:''}} }
export function saveSettings(s){localStorage.setItem(SETTINGS_KEY,JSON.stringify({room:s.room.trim(),pin:s.pin}));}
export async function api(path, { method='GET', pin, body }={}) {
  const response = await fetch(`/api/events${path}`, {
    method, cache:'no-store',
    headers:{'X-Portrait-Pin':pin, ...(body?{'Content-Type':'application/json'}:{})},
    ...(body?{body:JSON.stringify(body)}:{}),
  });
  let data;
  try {data=await response.json()}catch{throw new Error(`Server returned ${response.status} without JSON. Check deployment.`)}
  if(!response.ok)throw new Error(data.error||`HTTP ${response.status}`);
  return data;
}
export const sleep=(ms)=>new Promise(resolve=>setTimeout(resolve,ms));
export function setStatus(el, text, type='neutral'){el.textContent=text;el.dataset.type=type;}
export function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
