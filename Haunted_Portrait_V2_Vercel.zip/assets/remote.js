import { getSettings, saveSettings, api, setStatus } from './shared.js';
import {createPeer,completeLocalDescription,makeSession,signal,pollLoop} from './webrtc.js';
const $=id=>document.getElementById(id);
let connected=false,settings=getSettings(), style='monster', recorder=null,recorded=null,recordDataURL='', stream=null, recordingStarted=0, recordTimer=null,recordTimeout=null;
const phrases=[
  'I have been watching you all evening.',
  'That costume is terribly familiar…',
  'The last guest never made it out.',
  'You are standing on my favorite grave.',
  'Please do not touch the cursed furniture.',
  'Would you like to hear how I died?',
  'There is someone standing behind you.',
  'I was promised better company than this.'
];
const names={morrow:'MADAME MORROW',ashbury:'LORD ASHBURY',bellweather:'BELLWEATHER'};
function feedback(message,fail=false){$('feedback').textContent=message;$('feedback').style.color=fail?'#eeaa9d':'#d4b887'}
function requireConnection(){if(!connected){feedback('Connect to your room first.',true);$('connectPanel').scrollIntoView({behavior:'smooth'});return false}return true}
async function transmit(command){
  if(!requireConnection())return false;
  try{await api('',{method:'POST',pin:settings.pin,body:{room:settings.room,...command}});feedback('Command sent to the portrait.');return true}
  catch(e){feedback(e.message,true);setStatus($('connectionStatus'),'Connection failed','error');return false}
}
function connectedUI(){setStatus($('connectionStatus'),connected?`Relay connected · ${settings.room}`:'Not connected',connected?'success':'neutral');$('connectPanel').hidden=connected}
$('remoteConnectForm').addEventListener('submit',async e=>{e.preventDefault();const room=$('remoteRoom').value.trim(),pin=$('remotePin').value;setStatus($('remoteConnectStatus'),'Contacting portrait relay…');try{await api(`?room=${encodeURIComponent(room)}&init=1`,{pin});settings={room,pin};saveSettings(settings);connected=true;connectedUI();feedback('Connected. The portrait must also be awake on your tablet.');
    remotePoll&&(remotePoll.active=false);startRemotePolling((await api(`?room=${encodeURIComponent(room)}&init=1`,{pin})).lastId);}catch(err){setStatus($('remoteConnectStatus'),err.message,'error')}});
$('editConnection').addEventListener('click',()=>{connected=false;connectedUI();$('connectPanel').hidden=false;$('connectPanel').scrollIntoView({behavior:'smooth'})});
$('remoteRoom').value=settings.room||'halloween';$('remotePin').value=settings.pin||'';
if(settings.pin){$('remoteConnectStatus').textContent='Tap Connect to reconnect.'}
$('speakText').addEventListener('input',()=>{$('charCount').textContent=`${$('speakText').value.length} / 350`});
$('voiceStyleButtons').addEventListener('click',e=>{const btn=e.target.closest('[data-style]');if(!btn)return;style=btn.dataset.style;document.querySelectorAll('[data-style]').forEach(x=>x.classList.toggle('selected',x===btn))});
$('sendText').addEventListener('click',async()=>{const text=$('speakText').value.trim();if(!text){feedback('Write something to say first.',true);return}if(await transmit({kind:'speak',text,style})){$('speakText').value='';$('charCount').textContent='0 / 350'}});
for(const phrase of phrases){const button=document.createElement('button');button.textContent=`“${phrase}”`;button.type='button';button.addEventListener('click',()=>{$('speakText').value=phrase;$('charCount').textContent=`${phrase.length} / 350`;transmit({kind:'speak',text:phrase,style})});$('phraseGrid').append(button)}
document.querySelectorAll('[data-scene]').forEach(el=>el.addEventListener('click',()=>transmit({kind:'scene',scene:el.dataset.scene})));
$('stopAll').addEventListener('click',()=>transmit({kind:'stop'}));
document.querySelectorAll('[data-character]').forEach(el=>el.addEventListener('click',async()=>{if(await transmit({kind:'character',character:el.dataset.character})){document.querySelectorAll('[data-character]').forEach(x=>x.classList.toggle('selected',x===el));$('activeCharacter').textContent=names[el.dataset.character]}}));
function resetRecordUI(){$('recordButton').classList.remove('recording');$('recordButton').innerHTML='<span class="record-circle"></span> START RECORDING';clearInterval(recordTimer);clearTimeout(recordTimeout);}
async function startRecording(){
  if(!requireConnection())return;
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){feedback('Microphone recording is not supported in this browser.',true);return}
  try{
    stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
    const supported=['audio/webm;codecs=opus','audio/webm','audio/mp4'];const mimeType=supported.find(x=>MediaRecorder.isTypeSupported(x));
    recorder=new MediaRecorder(stream,{...(mimeType?{mimeType}:{}) ,audioBitsPerSecond:32000});
    const parts=[];recorded=null;recordDataURL='';$('recordPreview').hidden=true;
    recorder.ondataavailable=e=>{if(e.data.size)parts.push(e.data)};
    recorder.onstop=()=>{stream?.getTracks().forEach(track=>track.stop());stream=null;resetRecordUI();recorded=new Blob(parts,{type:recorder.mimeType||'audio/webm'});if(recorded.size>300000){feedback('Recording too large. Try a shorter message.',true);return}if(!recorded.size){feedback('No microphone audio was captured.',true);return}const fr=new FileReader();fr.onload=()=>{recordDataURL=fr.result;$('recordPreview').hidden=false;const audio=$('audioPreview');if(audio.dataset.objectUrl)URL.revokeObjectURL(audio.dataset.objectUrl);audio.dataset.objectUrl=URL.createObjectURL(recorded);audio.src=audio.dataset.objectUrl;$('recordInfo').textContent=`${(recorded.size/1024).toFixed(0)} KB captured. Select an effect above, then send.`;};fr.readAsDataURL(recorded)};
    recorder.start(250);recordingStarted=Date.now();$('recordButton').classList.add('recording');$('recordButton').innerHTML='<span class="record-circle"></span> STOP & REVIEW';
    const tick=()=>{$('recordTime').textContent=`00:${String(Math.min(10,Math.floor((Date.now()-recordingStarted)/1000))).padStart(2,'0')} / 00:10`};tick();recordTimer=setInterval(tick,200);recordTimeout=setTimeout(stopRecording,10000);feedback('Recording… speak into your phone.');
  }catch(e){stream?.getTracks().forEach(t=>t.stop());resetRecordUI();feedback(`Microphone unavailable: ${e.message}`,true)}
}
function stopRecording(){if(recorder?.state==='recording')recorder.stop();resetRecordUI()}
$('recordButton').addEventListener('click',()=>recorder?.state==='recording'?stopRecording():startRecording());
$('discardRecording').addEventListener('click',()=>{$('recordPreview').hidden=true;recorded=null;recordDataURL='';$('recordInfo').textContent='Recording discarded.'});
$('sendRecording').addEventListener('click',async()=>{if(!recordDataURL)return;const ok=await transmit({kind:'audio',audio:recordDataURL,style});if(ok){$('recordPreview').hidden=true;recorded=null;recordDataURL='';$('recordInfo').textContent='Recording sent to the portrait.'}});

// VERSION 2 / LIVE PUPPETEER
let rtc=null,rtcId='', liveStream=null, remotePoll=null, activeTalk=false, tabletLastSeen=0;
const liveButton=$('startLive'),ptt=$('holdTalk');
function liveFeedback(msg,type='neutral'){
  setStatus($('liveFeedback'),msg,type);
}
function liveState(label,type='neutral'){
  setStatus($('liveStatus'),label,type);
}
function talk(held){
  activeTalk=Boolean(held&&rtc?.connectionState==='connected'&&liveStream);
  if(liveStream){for(const t of liveStream.getAudioTracks())t.enabled=activeTalk;}
  ptt.classList.toggle('active',activeTalk);
  ptt.querySelector('strong').textContent=activeTalk?'SPEAKING…':'HOLD TO SPEAK';
  ptt.querySelector('small').textContent=activeTalk?'Release to silence the portrait':'Release to mute · Keep this page open';
}
function stopLive(send=true){
  talk(false);
  if(send&&connected&&rtcId){signal(settings.room,settings.pin,{from:'remote',action:'hangup',session:rtcId}).catch(()=>{});}
  rtc?.close();rtc=null;rtcId='';
  liveStream?.getTracks().forEach(t=>t.stop());liveStream=null;
  ptt.disabled=true;liveButton.textContent='CONNECT LIVE MICROPHONE';
  liveState('Offline');
}
async function startLive(){
  if(rtc){stopLive();liveFeedback('Microphone disconnected.');return;}
  if(!requireConnection())return;
  if(!window.RTCPeerConnection || !navigator.mediaDevices?.getUserMedia){liveFeedback('Live audio requires a modern browser on HTTPS (or localhost).','error');return;}
  liveButton.disabled=true;
  try{
    liveState('Requesting mic','warning');
    liveStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
    // Keep the connection up while silent; enable the track only when pressed.
    for(const track of liveStream.getAudioTracks())track.enabled=false;
    rtcId=makeSession();const thisSession=rtcId;
    const pc=createPeer(s=>{
      if(rtc!==pc)return;
      if(s==='connected'){
        liveState('Audio connected','success');ptt.disabled=false;
        liveFeedback('Hold the large button to talk. Audio is sent directly to the tablet.','success');
      }else if(['failed','closed'].includes(s)){
        stopLive(false);liveFeedback('Audio connection failed. Try reconnecting on the same Wi-Fi or configure a TURN relay.','error');
      }else if(s==='disconnected'){
        talk(false);ptt.disabled=true;liveState('Reconnecting','warning');
      }
    });
    rtc=pc;
    for(const track of liveStream.getTracks())pc.addTrack(track,liveStream);
    const offer=await pc.createOffer({offerToReceiveAudio:false});
    await pc.setLocalDescription(offer);
    const sdp=await completeLocalDescription(pc);
    if(rtc!==pc||rtcId!==thisSession)return;
    await signal(settings.room,settings.pin,{from:'remote',action:'offer',session:thisSession,sdp});
    liveState('Calling tablet','warning');
    liveButton.textContent='DISCONNECT LIVE AUDIO';
    liveFeedback('Waiting for the portrait to answer… Check that the tablet is awake and connected.','warning');
  }catch(e){stopLive(false);liveFeedback('Unable to start microphone: '+e.message,'error')}
  finally{liveButton.disabled=false;}
}
liveButton.addEventListener('click',startLive);
async function onRemoteSignal(e){
  if(e.kind==='presence'&&e.from==='portrait'){
    tabletLastSeen=Date.now();
    setStatus($('connectionStatus'),`Tablet online · ${settings.room}`,'success');
    return;
  }
  if(e.kind!=='rtc'||e.from!=='portrait'||e.session!==rtcId||!rtc)return;
  if(e.action==='answer'&&rtc.signalingState==='have-local-offer'){
    await rtc.setRemoteDescription({type:'answer',sdp:e.sdp});
    liveFeedback('Portrait answered. Establishing direct audio connection…','warning');
  }else if(e.action==='hangup'){stopLive(false);liveFeedback('Tablet ended the audio connection.');}
}
function startRemotePolling(lastId){
  remotePoll={active:true};const session=remotePoll;
  pollLoop({room:settings.room,pin:settings.pin,session,lastId,interval:1000,onEvent:onRemoteSignal,
    onError:e=>{console.warn('Remote message poll:',e.message)}});
}
$('editConnection').addEventListener('click',()=>{stopLive();if(remotePoll)remotePoll.active=false;tabletLastSeen=0});
ptt.addEventListener('pointerdown',e=>{if(ptt.disabled)return;e.preventDefault();ptt.setPointerCapture?.(e.pointerId);talk(true)});
ptt.addEventListener('pointerup',()=>talk(false));
ptt.addEventListener('pointercancel',()=>talk(false));
ptt.addEventListener('lostpointercapture',()=>talk(false));
ptt.addEventListener('keydown',e=>{if((e.code==='Space'||e.code==='Enter')&&!e.repeat){e.preventDefault();talk(true)}});
ptt.addEventListener('keyup',e=>{if(e.code==='Space'||e.code==='Enter'){e.preventDefault();talk(false)}});
window.addEventListener('blur',()=>talk(false));
document.addEventListener('visibilitychange',()=>{if(document.hidden)talk(false)});
window.addEventListener('pagehide',()=>{talk(false);rtc?.close();liveStream?.getTracks().forEach(t=>t.stop());});
$('liveStyle').addEventListener('change',e=>transmit({kind:'effect',style:e.target.value}));
document.querySelectorAll('[data-expression]').forEach(el=>el.addEventListener('click',()=>transmit({kind:'expression',expression:el.dataset.expression})));

setInterval(()=>{if(connected&&tabletLastSeen&&Date.now()-tabletLastSeen>30000){setStatus($('connectionStatus'),`Tablet not responding · ${settings.room}`,'warning');}},5000);
