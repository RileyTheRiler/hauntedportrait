// Granular dual-read-head pitch shifter. Meant for theatrical voice effects,
// not formant-preserving professional voice conversion.
class SpectralPitch extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [{name:'ratio',defaultValue:1,minValue:0.55,maxValue:1.6,automationRate:'k-rate'}];
  }
  constructor() {
    super();
    this.size=16384;
    this.buffers=[new Float32Array(this.size),new Float32Array(this.size)];
    this.position=0; this.phase=0;
    this.windowSize=Math.round(sampleRate*0.065);
  }
  read(buffer, pos) {
    const len=this.size;
    let p=((pos%len)+len)%len;
    const i=p|0, next=(i+1)%len;
    return buffer[i]+(buffer[next]-buffer[i])*(p-i);
  }
  process(inputs,outputs,params) {
    const input=inputs[0], output=outputs[0];
    if(!output?.length) return true;
    const ratio=params.ratio[0]||1;
    const win=this.windowSize;
    for(let i=0;i<output[0].length;i++) {
      const phaseA=this.phase;
      const phaseB=(phaseA+.5)%1;
      const weightA=.5-.5*Math.cos(phaseA*2*Math.PI);
      const weightB=1-weightA;
      for(let c=0;c<output.length;c++) {
        const buf=this.buffers[Math.min(c,1)];
        const current=input?.[Math.min(c,input.length-1)]?.[i]||0;
        buf[this.position]=current;
        if(Math.abs(ratio-1)<.015) { output[c][i]=current; continue; }
        // The moving read heads change playback speed within each grain.
        const base=350+Math.max(0,ratio-1)*win;
        const offsetA=base+(1-ratio)*phaseA*win;
        const offsetB=base+(1-ratio)*phaseB*win;
        output[c][i]=this.read(buf,this.position-offsetA)*weightA+this.read(buf,this.position-offsetB)*weightB;
      }
      this.position=(this.position+1)%this.size;
      this.phase=(this.phase+1/win)%1;
    }
    return true;
  }
}
registerProcessor('spectral-pitch',SpectralPitch);
