import {api, sleep} from './shared.js';
// Peer-to-peer WebRTC audio. Polling carries only negotiation SDP; never microphone audio.
// Waiting for ICE gathering lets this work with a simple, small REST event relay.
export const iceServers=[{urls:'stun:stun.l.google.com:19302'}];
export function createPeer(onState){
  const pc=new RTCPeerConnection({iceServers});
  pc.onconnectionstatechange=()=>onState(pc.connectionState);
  pc.oniceconnectionstatechange=()=>onState(pc.connectionState==='connecting'?pc.iceConnectionState:pc.connectionState);
  return pc;
}
export async function completeLocalDescription(pc){
  if(pc.iceGatheringState==='complete')return pc.localDescription.sdp;
  await new Promise(resolve=>{
    let done=false;
    const finish=()=>{if(done)return;done=true;pc.removeEventListener('icegatheringstatechange',check);clearTimeout(timer);resolve()};
    const check=()=>{if(pc.iceGatheringState==='complete')finish()};
    const timer=setTimeout(finish,6500);
    pc.addEventListener('icegatheringstatechange',check);check();
  });
  // SDP includes gathered candidates. No trickle candidates are sent in this prototype.
  return pc.localDescription.sdp;
}
export async function signal(room,pin,packet){return api('',{method:'POST',pin,body:{room,kind:'rtc',...packet}});}
export const makeSession=()=>crypto.randomUUID();
export async function pollLoop({room,pin,session,lastId,onEvent,interval=750,onError}){
  let cursor=lastId;
  while(session.active){
    try{
      const data=await api(`?room=${encodeURIComponent(room)}&since=${cursor}`,{pin});
      if(!session.active)break;
      for(const event of data.events||[]){cursor=Math.max(cursor,event.id);try{await onEvent(event)}catch(e){onError?.(e)}}
    } catch(e){onError?.(e)}
    if(session.active)await sleep(interval);
  }
}
