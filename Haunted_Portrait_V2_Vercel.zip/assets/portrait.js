import { getSettings, saveSettings, api, sleep, setStatus } from './shared.js';
import { LiveVoice } from './live-audio.js';
import { createPeer, completeLocalDescription, signal } from './webrtc.js';
const $=id=>document.getElementById(id);
const state={liveStyle:'monster',connected:false,room:'',pin:'',lastId:0,armed:false,processing:false,queue:[],animation:0,session:0,recordingSource:null,audioContext:null,wakeLock:null,selectedVoice:'',subtitles:true};
const characters={morrow:['MADAME MORROW','Keeper of the Last Word'],ashbury:['LORD ASHBURY','The Uninvited Host'],bellweather:['BELLWEATHER','Resident Since 1893']};
const styles={normal:{pitch:1,rate:1},monster:{pitch:.62,rate:.82},phantom:{pitch:1.25,rate:.86},witch:{pitch:.85,rate:1.08},robot:{pitch:.7,rate:.92}};
let activeTimer=null, stopPlayback=()=>{}, speaking=false;

function changeCharacter(character){
  if(!characters[character])return;
  document.body.classList.remove('character-morrow','character-ashbury','character-bellweather');
  document.body.classList.add(`character-${character}`);
  $('characterName').textContent=characters[character][0];
  $('characterSubtitle').textContent=characters[character][1];
}
function subtitle(text=''){
  $('subtitle').textContent=state.subtitles?text:'';
  $('subtitle').classList.toggle('visible',Boolean(text)&&state.subtitles);
}
function mouth(open=0){$('mouthGroup').style.transform=`translateY(${-Math.max(0,open)*6}px) scaleY(${1+Math.max(0,open)*3.7})`;}
function beginSpeaking(approximate=true){speaking=true;document.body.classList.add('is-speaking');cancelAnimationFrame(state.animation);if(!approximate)return;const start=performance.now();function tick(now){if(!speaking)return;mouth(.18 + (.28+.5*Math.abs(Math.sin((now-start)*.020)))*Math.random());state.animation=requestAnimationFrame(tick)}state.animation=requestAnimationFrame(tick);}
function endSpeaking(){speaking=false;document.body.classList.remove('is-speaking');cancelAnimationFrame(state.animation);mouth(0);subtitle('')}
function clearScene(){document.body.classList.remove('scene-possess','scene-glare','scene-blackout','scene-laugh');if(activeTimer){clearTimeout(activeTimer);activeTimer=null}}
function scene(name){clearScene();if(name==='idle')return;document.body.classList.add(`scene-${name}`);if(name==='laugh'){const u=new SpeechSynthesisUtterance('Ha! Ha! Ha! Ha ha haaaa!');u.pitch=.45;u.rate=.73;try{speechSynthesis.speak(u)}catch{}}activeTimer=setTimeout(clearScene,name==='possess'?6500:3800)}
function getVoice(){let list=speechSynthesis.getVoices();return list.find(v=>v.voiceURI===state.selectedVoice)||list.find(v=>/^en([_-]|$)/i.test(v.lang))||list[0]||null}
function populateVoices(){if(!('speechSynthesis' in window))return;const voices=speechSynthesis.getVoices();const select=$('voiceSelect');const old=select.value||state.selectedVoice;select.replaceChildren(new Option('Default device voice',''));for(const voice of voices){select.add(new Option(`${voice.name} (${voice.lang})`,voice.voiceURI))}if(voices.some(v=>v.voiceURI===old))select.value=old;}
function stopAll(){endLive(true);state.queue.length=0;try{speechSynthesis.cancel()}catch{}stopPlayback();stopPlayback=()=>{};clearScene();endSpeaking();}
async function playSpeech(text,style='monster'){
  if(!('speechSynthesis' in window))throw new Error('This browser has no speech synthesis. Use Chrome on Android.');
  speechSynthesis.cancel();
  const options=styles[style]||styles.monster;
  await new Promise(resolve=>{
    const utterance=new SpeechSynthesisUtterance(text);utterance.lang='en-US';utterance.pitch=options.pitch;utterance.rate=options.rate;utterance.volume=1;
    const voice=getVoice();if(voice)utterance.voice=voice;
    let settled=false;const finish=()=>{if(settled)return;settled=true;clearTimeout(watchdog);stopPlayback=()=>{};endSpeaking();resolve()};
    const watchdog=setTimeout(finish,Math.max(10000,text.length*240));
    stopPlayback=()=>{try{speechSynthesis.cancel()}catch{}finish()};
    utterance.onstart=()=>{beginSpeaking();subtitle(text)};
    utterance.onend=finish;utterance.onerror=finish;
    try{speechSynthesis.speak(utterance)}catch{finish()}
  });
}
async function getAudioContext(){state.audioContext ||= new (window.AudioContext||window.webkitAudioContext)();if(state.audioContext.state==='suspended')await state.audioContext.resume();return state.audioContext}
async function playRecorded(base64,style='monster'){
  const context=await getAudioContext();
  const b64=base64.split(',')[1];const bytes=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
  const buffer=await context.decodeAudioData(bytes.buffer.slice(0));
  const source=context.createBufferSource();source.buffer=buffer;
  const filter=context.createBiquadFilter();filter.type='lowpass';filter.frequency.value=style==='monster'?1600:style==='phantom'?3100:style==='robot'?2400:5000;
  const analyser=context.createAnalyser();analyser.fftSize=256;
  let speed={normal:1,monster:.74,phantom:1.16,witch:.91,robot:.99}[style]||1;
  source.playbackRate.value=speed;
  source.connect(filter);filter.connect(analyser);
  let audible=analyser;
  let oscil;
  if(style==='robot'){
    const amp=context.createGain();amp.gain.value=.55;
    oscil=context.createOscillator();const depth=context.createGain();depth.gain.value=.4;oscil.frequency.value=28;oscil.connect(depth);depth.connect(amp.gain);oscil.start();analyser.connect(amp);audible=amp;
  }
  const master=context.createGain();master.gain.value=.85;audible.connect(master);master.connect(context.destination);
  if(style==='phantom'||style==='witch'){
    const delay=context.createDelay(.6);delay.delayTime.value=style==='phantom'?.31:.16;
    const feedback=context.createGain();feedback.gain.value=style==='phantom'?.27:.16;
    const wet=context.createGain();wet.gain.value=.26;
    audible.connect(delay);delay.connect(wet);wet.connect(context.destination);delay.connect(feedback);feedback.connect(delay);
  }
  const data=new Uint8Array(analyser.frequencyBinCount);
  await new Promise(resolve=>{
    let done=false;const finish=()=>{if(done)return;done=true;if(oscil){try{oscil.stop()}catch{}}stopPlayback=()=>{};endSpeaking();resolve()};
    stopPlayback=()=>{try{source.stop()}catch{}finish()};
    source.onended=finish;beginSpeaking(false);subtitle('A voice speaks from within the portrait…');
    function frame(){if(done)return;analyser.getByteTimeDomainData(data);let sum=0;for(const n of data){const v=(n-128)/128;sum+=v*v}mouth(Math.min(.95,Math.sqrt(sum/data.length)*5));state.animation=requestAnimationFrame(frame)}
    source.start();frame();
  });
}
async function doEvent(event){
  if(event.kind==='stop'){stopAll();return;}
  if(event.kind==='expression'){facialExpression(event.expression);return;}
  if(event.kind==='effect'){state.liveStyle=event.style;liveVoice?.setStyle(event.style);return;}
  if(event.kind==='rtc'){if(event.from==='remote'){if(event.action==='offer')await receiveOffer(event);else if(event.action==='hangup'&&rtcSession===event.session)endLive();}return;}
  if(event.kind==='scene'){if(event.scene==='laugh')scene('laugh');else scene(event.scene);return;}
  if(event.kind==='character'){changeCharacter(event.character);return;}
  if(event.kind==='speak')await playSpeech(event.text,event.style);
  if(event.kind==='audio')await playRecorded(event.audio,event.style);
}
async function runQueue(){if(state.processing)return;state.processing=true;try{while(state.queue.length){const event=state.queue.shift();try{await doEvent(event)}catch(e){console.error('Playback error:',e);setStatus($('hudText'),`Audio error: ${e.message}`,'error')}}}finally{state.processing=false}}
async function poll(session){
  while(state.connected && state.session===session){
    try{
      const data=await api(`?room=${encodeURIComponent(state.room)}&since=${state.lastId}`,{pin:state.pin});
      if(!state.connected || state.session!==session)break;
      for(const event of data.events||[]){state.lastId=Math.max(state.lastId,event.id);
        if(event.kind==='stop'){stopAll();continue;}
        if(event.kind==='rtc'){await doEvent(event);continue;}
        if(event.kind==='character'||event.kind==='scene'||event.kind==='expression'||event.kind==='effect'){doEvent(event);continue;}
        state.queue.push(event);
      }
      runQueue();
      $('hudDot').classList.add('live');setStatus($('hudText'),`Listening · ${state.room}`,'success');
    }catch(e){$('hudDot').classList.remove('live');setStatus($('hudText'),`Disconnected · retrying`,'error');console.warn('Poll error:',e.message)}
    await sleep(850);
  }
}
async function arm(){
  await getAudioContext();
  try{if('wakeLock' in navigator)state.wakeLock=await navigator.wakeLock.request('screen')}catch{}
  try{await document.documentElement.requestFullscreen?.()}catch{}
  populateVoices();
  // A real click is necessary to allow future synthesized speech/audio on Android.
  if('speechSynthesis' in window){try{speechSynthesis.cancel();const warmup=new SpeechSynthesisUtterance(' ');warmup.volume=0;speechSynthesis.speak(warmup)}catch{}}
  state.armed=true;
}
async function connect(room,pin){
  $('formStatus').textContent='Connecting to the spectral relay…';
  await arm();
  const init=await api(`?room=${encodeURIComponent(room)}&init=1`,{pin});
  state.connected=false;endLive();
  state.room=room;state.pin=pin;state.lastId=init.lastId||0;state.connected=true;state.session++;
  saveSettings({room,pin});$('setupScrim').hidden=true;$('displaySettings').hidden=true;
  $('connectionInfo').textContent=`Room: ${room} · Checking for commands about every 0.85 seconds`;
  poll(state.session);
  if(state.presenceTimer)clearInterval(state.presenceTimer);
  const heartbeat=()=>api('',{method:'POST',pin:state.pin,body:{room:state.room,kind:'presence',from:'portrait'}}).catch(()=>{});
  heartbeat();state.presenceTimer=setInterval(()=>{if(state.connected)heartbeat()},12000);
}
$('connectForm').addEventListener('submit',async e=>{e.preventDefault();const room=$('roomInput').value.trim();const pin=$('pinInput').value;try{await connect(room,pin)}catch(err){$('formStatus').textContent=err.message}});
$('settingsButton').addEventListener('click',()=>{$('displaySettings').hidden=!$('displaySettings').hidden});
$('closeSettings').addEventListener('click',()=>{$('displaySettings').hidden=true});
$('testVoice').addEventListener('click',()=>playSpeech('I have been waiting for you.','monster'));
$('reconnectButton').addEventListener('click',()=>{clearInterval(state.presenceTimer);state.connected=false;state.session++;stopAll();$('setupScrim').hidden=false;$('displaySettings').hidden=true});
$('fullscreenButton').addEventListener('click',()=>document.documentElement.requestFullscreen?.());
$('voiceSelect').addEventListener('change',e=>{state.selectedVoice=e.target.value;localStorage.setItem('haunted-voice',state.selectedVoice)});
$('subtitlesToggle').addEventListener('change',e=>{state.subtitles=e.target.checked;subtitle('')});
window.speechSynthesis?.addEventListener('voiceschanged',populateVoices);
document.addEventListener('visibilitychange',async()=>{if(!document.hidden&&state.armed&&!state.wakeLock){try{state.wakeLock=await navigator.wakeLock?.request('screen')}catch{}}});
const settings=getSettings();$('roomInput').value=settings.room||'halloween';$('pinInput').value=settings.pin||'';state.selectedVoice=localStorage.getItem('haunted-voice')||'';populateVoices();

// VERSION 2 / LIVE PUPPETEER — WebRTC setup exchanges only session descriptions.
// Raw microphone audio goes directly from phone -> tablet through RTCPeerConnection.
let rtcPeer=null, rtcSession='', liveVoice=null, lastPresence=0;
const expressions=['idle','watch','smirk','scowl','startled'];
let currentExpression='idle', blinkTimer;
function facialExpression(name='idle') {
  if(!expressions.includes(name))return;
  document.body.classList.remove(...expressions.map(x=>'expression-'+x));
  document.body.classList.add('expression-'+name);
  currentExpression=name;
  if(name==='startled'){clearTimeout(facialExpression.timeout);facialExpression.timeout=setTimeout(()=>facialExpression('watch'),2200)}
}
function blinkLoop(){
  clearTimeout(blinkTimer);
  blinkTimer=setTimeout(()=>{
    if(!document.body.classList.contains('scene-possess')){
      document.body.classList.add('blink');setTimeout(()=>document.body.classList.remove('blink'),145);
    }
    blinkLoop();
  },2400+Math.random()*4800);
}
blinkLoop();
let idleTimer=setInterval(()=>{
  if(!state.connected)return;
  if(document.body.classList.contains('scene-possess'))return;
  if(!document.body.classList.contains('idle-still')&&!speaking&&!liveVoice?.stream){
    facialExpression(Math.random()<.6?'idle':'watch');
    $('pupils').style.transform=`translate(${(Math.random()-.5)*9}px,${(Math.random()-.5)*4}px)`;
  }
},7800);
$('idleToggle').addEventListener('change',e=>document.body.classList.toggle('idle-still',!e.target.checked));
$('gazeToggle').addEventListener('change',e=>{if(!e.target.checked)$('pupils').style.transform='translate(0,0)'});
$('portraitStage').addEventListener('pointermove',e=>{
  if(!$('gazeToggle').checked)return;
  const r=$('portraitStage').getBoundingClientRect();
  const x=(e.clientX-(r.left+r.width/2))/r.width;
  const y=(e.clientY-(r.top+r.height/2))/r.height;
  $('pupils').style.transform=`translate(${Math.max(-13,Math.min(13,x*26))}px,${Math.max(-7,Math.min(7,y*14))}px)`;
});
function endLive(notify=false){
  if(notify&&state.connected&&rtcSession){signal(state.room,state.pin,{from:'portrait',action:'hangup',session:rtcSession}).catch(()=>{});}
  rtcPeer?.close();rtcPeer=null;rtcSession='';
  liveVoice?.stop();
  $('liveVoiceStatus').textContent='Live microphone: idle';
  document.body.classList.remove('live-speaking');
  mouth(0);
}
async function receiveOffer(event){
  if(!state.connected)return;
  endLive();
  rtcSession=event.session;
  const current=rtcSession;
  const pc=createPeer(s=>{
    if(rtcPeer!==pc)return;
    $('liveVoiceStatus').textContent='Live microphone: '+s;
    if(['disconnected','failed','closed'].includes(s)&&s!=='disconnected')endLive();
  });rtcPeer=pc;
  pc.ontrack=async e=>{
    if(rtcPeer!==pc)return;
    try{
      const stream=e.streams[0]||new MediaStream([e.track]);
      const context=await getAudioContext();
      liveVoice=new LiveVoice(context,level=>{
        if(!speaking){mouth(Math.min(1,level));document.body.classList.toggle('live-speaking',level>.065);}
      });
      await liveVoice.setStream(stream);liveVoice.setStyle(state.liveStyle||'monster');
      $('liveVoiceStatus').textContent='Live microphone: receiving';
      facialExpression('watch');
      e.track.addEventListener('ended',()=>{if(rtcPeer===pc)endLive()},{once:true});
    }catch(err){$('liveVoiceStatus').textContent='Audio problem: '+err.message}
  };
  await pc.setRemoteDescription({type:'offer',sdp:event.sdp});
  const answer=await pc.createAnswer();
  await pc.setLocalDescription(answer);
  const sdp=await completeLocalDescription(pc);
  if(rtcPeer===pc&&rtcSession===current)await signal(state.room,state.pin,{from:'portrait',action:'answer',session:current,sdp});
}
// The ordinary stop command silences recorded and synthesized speech, and
// additionally clears live playback on an explicit emergency stop.
$('reconnectButton').addEventListener('click',()=>endLive());
window.addEventListener('pagehide',()=>endLive());
