// Incoming WebRTC audio is processed and played on the tablet.
// Changing presets rebuilds Web Audio connections without renegotiating WebRTC.
export class LiveVoice {
  constructor(context, onLevel=()=>{}) {
    this.context=context; this.onLevel=onLevel; this.stream=null; this.nodes=[]; this.osc=[];
    this.source=null; this.analyser=null; this.style='monster'; this.generation=0;
    this.sampling=new Uint8Array(256); this.frame=0;
  }
  async setStream(stream) {
    this.stop();
    this.stream=stream;
    await this.context.resume();
    this.source=this.context.createMediaStreamSource(stream);
    try {
      if(!this.context.audioWorklet) throw new Error('AudioWorklet not supported');
      if(!LiveVoice.workletLoaded) LiveVoice.workletLoaded=this.context.audioWorklet.addModule('/assets/live-effects-worklet.js');
      await LiveVoice.workletLoaded;
      this.workletAvailable=true;
    } catch(e) { this.workletAvailable=false; console.warn('Pitch shifter fallback:', e); }
    this.setStyle(this.style);
    this.meter();
  }
  setStyle(style) {
    this.style=['normal','monster','phantom','witch','robot','doll'].includes(style)?style:'normal';
    if(!this.source) return;
    this.teardown();
    const ctx=this.context;
    const add=node=>{this.nodes.push(node);return node};
    const input=add(ctx.createHighpass());input.frequency.value=style==='phantom'?260:style==='robot'?210:65;
    this.source.connect(input);
    let tail=input;
    if(this.workletAvailable){
      const shift=add(new AudioWorkletNode(ctx,'spectral-pitch'));
      const ratios={normal:1,monster:.73,phantom:1.12,witch:.9,robot:.94,doll:1.37};
      shift.parameters.get('ratio').value=ratios[this.style];
      tail.connect(shift);tail=shift;
    }
    const filter=add(ctx.createBiquadFilter());filter.type='lowpass';
    filter.frequency.value={normal:11000,monster:2250,phantom:6100,witch:3400,robot:2600,doll:7500}[this.style];
    tail.connect(filter);tail=filter;
    if(this.style==='monster'||this.style==='robot'){
      const shaper=add(ctx.createWaveShaper());
      const curve=new Float32Array(2048);
      const k=this.style==='robot'?28:10;
      for(let i=0;i<2048;i++){const x=2*i/2047-1;curve[i]=(1+k)*x/(1+k*Math.abs(x));}
      shaper.curve=curve;shaper.oversample='2x';tail.connect(shaper);tail=shaper;
    }
    if(this.style==='robot'){
      const gain=add(ctx.createGain());gain.gain.value=.54;
      const depth=add(ctx.createGain());depth.gain.value=.35;
      const osc=ctx.createOscillator();osc.frequency.value=37;
      osc.connect(depth);depth.connect(gain.gain);osc.start();this.osc.push(osc);
      tail.connect(gain);tail=gain;
    }
    const mix=add(ctx.createGain());mix.gain.value=1;
    tail.connect(mix);
    if(['phantom','witch','monster'].includes(this.style)){
      const delay=add(ctx.createDelay(.6));
      delay.delayTime.value={phantom:.25,witch:.12,monster:.095}[this.style];
      const feedback=add(ctx.createGain());feedback.gain.value={phantom:.26,witch:.14,monster:.10}[this.style];
      const wet=add(ctx.createGain());wet.gain.value={phantom:.30,witch:.19,monster:.12}[this.style];
      tail.connect(delay);delay.connect(wet);wet.connect(mix);delay.connect(feedback);feedback.connect(delay);
    }
    const limiter=add(ctx.createDynamicsCompressor());
    limiter.threshold.value=-15;limiter.knee.value=8;limiter.ratio.value=4;limiter.attack.value=.006;limiter.release.value=.16;
    mix.connect(limiter);
    this.analyser=add(ctx.createAnalyser());this.analyser.fftSize=512;
    limiter.connect(this.analyser);this.analyser.connect(ctx.destination);
  }
  meter(){
    const generation=++this.generation;
    const sample=new Uint8Array(256);
    let smooth=0;
    const tick=()=>{
      if(generation!==this.generation)return;
      if(this.analyser){this.analyser.getByteTimeDomainData(sample);let sum=0;for(const x of sample){const v=(x-128)/128;sum+=v*v;}const level=Math.min(1,Math.sqrt(sum/sample.length)*7);smooth=smooth*.6+level*.4;this.onLevel(smooth);}
      this.frame=requestAnimationFrame(tick);
    };tick();
  }
  teardown(){
    for(const osc of this.osc){try{osc.stop()}catch{}try{osc.disconnect()}catch{}}
    this.osc=[];
    this.source?.disconnect();
    for(const node of this.nodes){try{node.disconnect()}catch{}}
    this.nodes=[];this.analyser=null;
  }
  stop(){this.generation++;cancelAnimationFrame(this.frame);this.teardown();this.source=null;this.stream=null;this.onLevel(0);}
}
