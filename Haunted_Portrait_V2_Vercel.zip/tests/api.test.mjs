import test from 'node:test';
import assert from 'node:assert/strict';
import { authorized, roomName, eventPayload } from '../api/events.js';
test('PIN authorization',()=>{ assert.equal(authorized('haunt2026','haunt2026'),true); assert.equal(authorized('wrong','haunt2026'),false); assert.equal(authorized('a','a'),false); });
test('room validation',()=>{ assert.equal(roomName('My-Room'),'my-room'); assert.throws(()=>roomName('../etc')); });
test('command validation',()=>{ assert.equal(eventPayload({kind:'speak',text:' hello ',style:'monster'}).text,'hello'); assert.throws(()=>eventPayload({kind:'speak',text:''})); assert.throws(()=>eventPayload({kind:'scene',scene:'dangerous'})); });

test('WebRTC offer and answer validation',()=>{
 const valid='v=0\r\no=- 0 0 IN IP4 127.0.0.1\r\ns=Haunted Portrait\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111';
 const offer=eventPayload({kind:'rtc',action:'offer',session:'deadbeef-1234',from:'remote',sdp:valid});
 assert.equal(offer.sdp,valid);
 assert.equal(eventPayload({kind:'rtc',action:'hangup',session:'deadbeef-1234',from:'portrait'}).action,'hangup');
 assert.throws(()=>eventPayload({kind:'rtc',action:'offer',session:'bad',from:'remote',sdp:valid}));
 assert.throws(()=>eventPayload({kind:'rtc',action:'answer',session:'deadbeef-1234',from:'portrait',sdp:'garbage'}));
 assert.throws(()=>eventPayload({kind:'rtc',action:'candidate',session:'deadbeef-1234',from:'remote',sdp:valid}));
});
test('live effects, presence and facial expressions are validated',()=>{
 assert.equal(eventPayload({kind:'effect',style:'doll'}).style,'doll');
 assert.equal(eventPayload({kind:'expression',expression:'smirk'}).expression,'smirk');
 assert.equal(eventPayload({kind:'presence',from:'portrait'}).from,'portrait');
 assert.throws(()=>eventPayload({kind:'effect',style:'javascript:alert(1)'}));
 assert.throws(()=>eventPayload({kind:'presence',from:'remote'}));
});
