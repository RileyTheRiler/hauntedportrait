import { createHash, timingSafeEqual } from 'node:crypto';

const MAX_AUDIO_DATA_URL = 450_000;
const MAX_BODY = 500_000;
const EXPIRATION_SECONDS = 60 * 60 * 12;
const NO_CACHE = { 'Cache-Control': 'private, no-store, max-age=0' };
const KINDS = new Set(['speak', 'audio', 'scene', 'stop', 'character', 'rtc', 'presence', 'expression', 'effect']);
const STYLES = new Set(['normal', 'monster', 'phantom', 'witch', 'robot']);
const SCENES = new Set(['glare', 'possess', 'blackout', 'laugh', 'idle']);
const CHARACTERS = new Set(['morrow', 'ashbury', 'bellweather']);
const EXPRESSIONS = new Set(['idle','watch','smirk','scowl','startled']);
const RTC_ACTIONS = new Set(['offer','answer','hangup']);

function authorized(pin, expected) {
  if (typeof pin !== 'string' || !expected || expected.length < 6) return false;
  const receivedDigest = createHash('sha256').update(pin).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(receivedDigest, expectedDigest);
}
function roomName(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{3,24}$/.test(value)) throw Object.assign(new Error('Room name must have 3–24 letters, numbers, dashes, or underscores.'), { status: 400 });
  return value.toLowerCase();
}
function eventPayload(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw) || !KINDS.has(raw.kind)) throw Object.assign(new Error('Unrecognized event.'), { status: 400 });
  const event = { kind: raw.kind };
  if (raw.kind === 'speak') {
    if (typeof raw.text !== 'string' || !raw.text.trim() || raw.text.length > 350) throw Object.assign(new Error('Text must contain 1–350 characters.'), { status: 400 });
    event.text = raw.text.trim();
    event.style = STYLES.has(raw.style) ? raw.style : 'monster';
  } else if (raw.kind === 'audio') {
    if (typeof raw.audio !== 'string' || raw.audio.length > MAX_AUDIO_DATA_URL || !/^data:audio\/(webm|ogg|mp4|mpeg|wav)(;[^,]*)?;base64,[A-Za-z0-9+/=]+$/.test(raw.audio)) throw Object.assign(new Error('Recording must be a supported audio file under 450 KB.'), { status: 400 });
    event.audio = raw.audio;
    event.style = STYLES.has(raw.style) ? raw.style : 'monster';
  } else if (raw.kind === 'scene') {
    if (!SCENES.has(raw.scene)) throw Object.assign(new Error('Unknown scene.'), { status: 400 });
    event.scene = raw.scene;
  } else if (raw.kind === 'rtc') {
    if (!RTC_ACTIONS.has(raw.action) || !['remote', 'portrait'].includes(raw.from) ||
        typeof raw.session !== 'string' || !/^[a-zA-Z0-9-]{8,64}$/.test(raw.session))
      throw Object.assign(new Error('Invalid audio connection event.'), {status:400});
    event.action=raw.action;event.from=raw.from;event.session=raw.session;
    if(raw.action!=='hangup'){
      if(typeof raw.sdp !== 'string' || raw.sdp.length<50 || raw.sdp.length>24000 || !raw.sdp.startsWith('v=0'))
        throw Object.assign(new Error('Invalid WebRTC session description.'), {status:400});
      event.sdp=raw.sdp;
    }
  } else if(raw.kind === 'effect') {
    if(!['normal','monster','phantom','witch','robot','doll'].includes(raw.style)) throw Object.assign(new Error('Unknown voice effect.'),{status:400});
    event.style=raw.style;
  } else if(raw.kind === 'presence') {
    if(raw.from!=='portrait') throw Object.assign(new Error('Invalid presence sender.'), {status:400});
    event.from='portrait';
  } else if(raw.kind === 'expression') {
    if(!EXPRESSIONS.has(raw.expression)) throw Object.assign(new Error('Unknown facial expression.'),{status:400});
    event.expression=raw.expression;
  } else if (raw.kind === 'character') {
    if (!CHARACTERS.has(raw.character)) throw Object.assign(new Error('Unknown character.'), { status: 400 });
    event.character = raw.character;
  }
  return event;
}

function getRedisConfig() {
  return {
    url: process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL,
    token: process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN,
  };
}

async function redis(commands) {
  const { url, token } = getRedisConfig();
  if (!url || !token) throw Object.assign(new Error('Remote control is not configured. Connect Upstash Redis to this Vercel project.'), { status: 503 });
  const response = await fetch(`${url.replace(/\/$/, '')}/pipeline`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(commands),
    signal: AbortSignal.timeout(6000),
  });
  if (!response.ok) throw Object.assign(new Error('Redis service returned an error.'), { status: 502 });
  const data = await response.json();
  if (!Array.isArray(data) || data.some(x => x && x.error)) throw Object.assign(new Error('Redis command failed.'), { status: 502 });
  return data.map(item => item.result);
}

function send(res, status, data) {
  res.status(status);
  res.setHeader('Cache-Control', NO_CACHE['Cache-Control']);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.json(data);
}

export default async function handler(req, res) {
  if (req.method !== 'GET' && req.method !== 'POST') return send(res, 405, { error: 'Method not allowed.' });
  const expected = process.env.PORTRAIT_PIN;
  if (!expected || expected.length < 6) return send(res, 503, { error: 'Set PORTRAIT_PIN to a private PIN of at least 6 characters in Vercel.' });
  if (!authorized(req.headers['x-portrait-pin'], expected)) return send(res, 401, { error: 'Incorrect private PIN.' });
  try {
    let room, listKey, seqKey;
    if (req.method === 'GET') {
      room = roomName(req.query.room);
      listKey = `haunted:v2:${room}:events`;
      seqKey = `haunted:v2:${room}:seq`;
      if (req.query.init === '1') {
        const [last] = await redis([['GET', seqKey]]);
        return send(res, 200, { lastId: Number(last) || 0, events: [] });
      }
      const since = Math.max(0, Math.min(Number(req.query.since) || 0, Number.MAX_SAFE_INTEGER));
      const [rawEvents] = await redis([['LRANGE', listKey, '-120', '-1']]);
      const parsed = Array.isArray(rawEvents) ? rawEvents.map(s => { try { return JSON.parse(s); } catch { return null; } }).filter(Boolean) : [];
      const events = parsed.filter(e => e.id > since).slice(0, 120);
      return send(res, 200, { events, lastId: events.at(-1)?.id || since });
    }
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    if (Buffer.byteLength(JSON.stringify(body ?? {}), 'utf8') > MAX_BODY) return send(res, 413, { error: 'Request too large.' });
    room = roomName(body?.room);
    const event = eventPayload(body);
    listKey = `haunted:v2:${room}:events`;
    seqKey = `haunted:v2:${room}:seq`;
    const [id] = await redis([['INCR', seqKey], ['EXPIRE', seqKey, EXPIRATION_SECONDS]]);
    const queued = { ...event, id: Number(id), at: Date.now() };
    await redis([['RPUSH', listKey, JSON.stringify(queued)], ['LTRIM', listKey, '-120', '-1'], ['EXPIRE', listKey, EXPIRATION_SECONDS]]);
    return send(res, 200, { ok: true, id: queued.id });
  } catch (e) {
    if (e?.name === 'TimeoutError') return send(res, 504, { error: 'Remote relay timed out.' });
    return send(res, e.status || 500, { error: e.status ? e.message : 'Remote relay unavailable. Check your project configuration.' });
  }
}

export { authorized, roomName, eventPayload };
